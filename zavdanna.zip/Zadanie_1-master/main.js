
const math = require('./node_modules/math/index')

let arr = [5,8,9,45,25,36,78,95,0,1,23,47]


math.absNum(-5)

math.arrSumm(arr)

math.minNum(arr)